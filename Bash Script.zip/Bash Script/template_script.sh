#!/bin/sh

file="F:/Bash_Shell/template.properties"
. $file

template="F:/Bash_Shell/Template.html"


    mkdir -p "F:/Bash_Shell/$environment"


    cp -a "$template" "F:/Bash_Shell/$environment/"$environment.html

destFile="F:/Bash_Shell/$environment/"$environment.html


sed -i -e "s/\[\[environment\]\]/$environment/g" F:/Bash_Shell/$environment/$environment.html
sed -i -e "s/\[\[title\]\]/$title/g" F:/Bash_Shell/$environment/$environment.html
	


read -p "$*"
